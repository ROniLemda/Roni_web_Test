"use server"

import { cookies, headers } from "next/headers"
import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"

interface SignInResult {
  success: boolean
  message?: string
  requires2FA?: boolean
  qrCodeImageUrl?: string
  sharedSecret?: string
}

export async function signInWithEmailAndPassword(email: string, password: string): Promise<SignInResult> {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)
  const requestHeaders = headers()

  // Attempt to get the client's IP address
  // Vercel populates 'x-forwarded-for' with the client's IP
  const ipAddress = requestHeaders.get("x-forwarded-for") || requestHeaders.get("x-real-ip") || "Unknown IP"
  console.log(`Login attempt from IP: ${ipAddress} for email: ${email}`)

  const { data, error } = await supabase.auth.signInWithPassword({ email, password })

  if (error) {
    if (error.message.includes("A multi-factor authentication challenge is required")) {
      return { success: false, message: "אימות דו-שלבי נדרש. אנא הזן את הקוד מאפליקציית המאמת שלך.", requires2FA: true }
    }
    console.error("Sign-in error:", error.message)
    return { success: false, message: error.message }
  }

  if (data.user) {
    // Check if the signed-in user is the allowed admin user
    if (data.user.email === "roniking63@gmail.com") {
      redirect("/dashboard")
      return { success: true } // This line won't be reached due to redirect
    } else {
      // If not the allowed user, sign them out immediately and return an error
      await supabase.auth.signOut()
      return { success: false, message: "אין לך הרשאה לגשת ללוח המחוונים." }
    }
  }

  return { success: false, message: "שגיאה בלתי צפויה בהתחברות." }
}

export async function verify2FACode(email: string, twoFactorCode: string): Promise<SignInResult> {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)
  const requestHeaders = headers()

  const ipAddress = requestHeaders.get("x-forwarded-for") || requestHeaders.get("x-real-ip") || "Unknown IP"
  console.log(`2FA verification attempt from IP: ${ipAddress} for email: ${email}`)

  const { error } = await supabase.auth.verifyOtp({
    email,
    token: twoFactorCode,
    type: "totp",
  })

  if (error) {
    console.error("2FA verification error:", error.message)
    return { success: false, message: `שגיאת אימות קוד: ${error.message}` }
  }

  // After 2FA verification, re-check if it's the allowed user before redirecting
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (user && user.email === "roniking63@gmail.com") {
    redirect("/dashboard")
    return { success: true } // This line won't be reached due to redirect
  } else {
    await supabase.auth.signOut() // Sign out if 2FA passed but user is not the admin
    return { success: false, message: "אין לך הרשאה לגשת ללוח המחוונים." }
  }
}

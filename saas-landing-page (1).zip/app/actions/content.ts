"use server"

import { cookies } from "next/headers"
import { createClient } from "@/lib/supabase/server"

interface HeroContent {
  id?: string
  title: string
  description: string
}

interface ContentActionResult {
  success: boolean
  message: string
  data?: HeroContent
}

export async function getHeroContent(): Promise<HeroContent | null> {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return null
  }

  const { data, error } = await supabase
    .from("hero_content")
    .select("id, title, description")
    .eq("user_id", user.id)
    .single()

  if (error && error.code !== "PGRST116") {
    // PGRST116 means no rows found
    console.error("Error fetching hero content:", error.message)
    return null
  }

  return data || null
}

export async function upsertHeroContent(
  id: string | undefined,
  title: string,
  description: string,
): Promise<ContentActionResult> {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return { success: false, message: "נדרשת התחברות כדי לעדכן תוכן." }
  }

  const contentData = {
    title,
    description,
    user_id: user.id,
  }

  let result
  if (id) {
    // Update existing content
    result = await supabase
      .from("hero_content")
      .update(contentData)
      .eq("id", id)
      .eq("user_id", user.id)
      .select("id, title, description")
      .single()
  } else {
    // Insert new content
    result = await supabase.from("hero_content").insert(contentData).select("id, title, description").single()
  }

  if (result.error) {
    console.error("Error upserting hero content:", result.error.message)
    return { success: false, message: `שגיאה בעדכון תוכן: ${result.error.message}` }
  }

  return { success: true, message: "תוכן הגיבור עודכן בהצלחה!", data: result.data }
}

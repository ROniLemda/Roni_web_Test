"use server"

import { cookies } from "next/headers"
import { createClient } from "@/lib/supabase/server"
import { revalidatePath } from "next/cache"

interface ProjectData {
  name: string
  description: string | null
  status: string
  start_date: string | null
  end_date: string | null
  client_id: string
}

interface ProjectActionResult {
  success: boolean
  message: string
}

// Fetch a single project by ID
export async function getProjectById(id: string) {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return null
  }

  const { data, error } = await supabase
    .from("projects")
    .select(
      `
    id,
    name,
    description,
    status,
    start_date,
    end_date,
    client_id,
    clients (
      name,
      company
    )
  `,
    )
    .eq("id", id)
    .single()

  if (error) {
    console.error("Error fetching project:", error.message)
    return null
  }

  return data
}

// Update an existing project
export async function updateProject(id: string, projectData: ProjectData): Promise<ProjectActionResult> {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return { success: false, message: "נדרשת התחברות כדי לעדכן פרויקט." }
  }

  const { error } = await supabase.from("projects").update(projectData).eq("id", id).eq("user_id", user.id) // Ensure user owns the project

  if (error) {
    console.error("Error updating project:", error.message)
    return { success: false, message: `שגיאה בעדכון פרויקט: ${error.message}` }
  }

  revalidatePath("/dashboard/projects") // Revalidate the projects list page
  return { success: true, message: "הפרויקט עודכן בהצלחה!" }
}

// Delete a project
export async function deleteProject(id: string): Promise<ProjectActionResult> {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return { success: false, message: "נדרשת התחברות כדי למחוק פרויקט." }
  }

  const { error } = await supabase.from("projects").delete().eq("id", id).eq("user_id", user.id) // Ensure user owns the project

  if (error) {
    console.error("Error deleting project:", error.message)
    return { success: false, message: `שגיאה במחיקת פרויקט: ${error.message}` }
  }

  revalidatePath("/dashboard/projects") // Revalidate the projects list page
  return { success: true, message: "הפרויקט נמחק בהצלחה!" }
}

"use server"

import { Resend } from "resend"

// Retrieve API key and sender email from environment variables
const resendApiKey = process.env.RESEND_API_KEY
const fromEmailAddress = process.env.FROM_EMAIL_ADDRESS || "onboarding@resend.dev" // Fallback for sender email

// Validate that the API key is present
if (!resendApiKey) {
  throw new Error(
    "RESEND_API_KEY is not set. Please ensure it is configured in your Vercel project environment variables.",
  )
}

const resend = new Resend(resendApiKey)

export async function sendContactEmail(formData: FormData) {
  const name = formData.get("name") as string
  const email = formData.get("email") as string
  const subject = formData.get("subject") as string
  const message = formData.get("message") as string

  if (!name || !email || !subject || !message) {
    return { success: false, message: "אנא מלא את כל השדות הנדרשים." }
  }

  try {
    const { data, error } = await resend.emails.send({
      from: fromEmailAddress, // Use the configured sender email
      to: "roniking63@gmail.com", // The recipient email address
      subject: `WebFlow Solutions - הודעה חדשה: ${subject}`,
      html: `
        <p><strong>שם:</strong> ${name}</p>
        <p><strong>אימייל:</strong> ${email}</p>
        <p><strong>נושא:</strong> ${subject}</p>
        <p><strong>הודעה:</strong></p>
        <p>${message}</p>
      `,
    })

    if (error) {
      console.error("Error sending email:", error)
      return { success: false, message: `שגיאה בשליחת ההודעה: ${error.message}` }
    }

    console.log("Email sent successfully:", data)
    return { success: true, message: "הודעתך נשלחה בהצלחה! ניצור קשר בהקדם." }
  } catch (error: any) {
    console.error("Unexpected error sending email:", error)
    return { success: false, message: `שגיאה בלתי צפויה: ${error.message || "נסה שוב מאוחר יותר."}` }
  }
}

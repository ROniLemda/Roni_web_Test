"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client" // Changed back to alias
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import Link from "next/link"

export default function AddClientPage() {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [company, setCompany] = useState("")
  const [message, setMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleAddClient = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setMessage("")

    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      setMessage("יש להתחבר כדי להוסיף לקוחות.")
      setIsLoading(false)
      return
    }

    const { error } = await supabase.from("clients").insert({
      name,
      email,
      company: company || null,
      user_id: user.id,
    })

    if (error) {
      setMessage(`שגיאה בהוספת לקוח: ${error.message}`)
    } else {
      setMessage("לקוח נוסף בהצלחה!")
      setName("")
      setEmail("")
      setCompany("")
      router.push("/dashboard") // Redirect to dashboard after adding
    }
    setIsLoading(false)
  }

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-purple-800">הוסף לקוח חדש</CardTitle>
          <CardDescription className="text-gray-600">מלא את הפרטים של הלקוח החדש שלך.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAddClient} className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="name">שם לקוח</Label>
              <Input
                id="name"
                type="text"
                placeholder="שם מלא"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                disabled={isLoading}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">אימייל</Label>
              <Input
                id="email"
                type="email"
                placeholder="client@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={isLoading}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="company">חברה (אופציונלי)</Label>
              <Input
                id="company"
                type="text"
                placeholder="שם החברה"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                disabled={isLoading}
              />
            </div>
            <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700 text-white" disabled={isLoading}>
              {isLoading ? "מוסיף..." : "הוסף לקוח"}
            </Button>
            {message && <p className="text-center text-sm text-red-500">{message}</p>}
          </form>
          <div className="mt-4 text-center">
            <Button variant="link" asChild className="text-purple-600">
              <Link href="/dashboard">חזור ללוח המחוונים</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import Link from "next/link"
import { getHeroContent, upsertHeroContent } from "@/app/actions/content"

export default function ManageHeroContentPage() {
  const [id, setId] = useState<string | undefined>(undefined)
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [message, setMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const fetchContent = async () => {
      setIsLoading(true)
      const content = await getHeroContent()
      if (content) {
        setId(content.id)
        setTitle(content.title)
        setDescription(content.description)
      } else {
        // Set default values if no content exists
        setTitle("בנה את הנוכחות הדיגיטלית הבאה שלך איתנו")
        setDescription("אנו יוצרים אתרים מודרניים, רספונסיביים ומותאמים אישית שיעזרו לעסק שלך לשגשג באינטרנט.")
      }
      setIsLoading(false)
    }
    fetchContent()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setMessage("")

    const result = await upsertHeroContent(id, title, description)

    if (result.success) {
      setMessage(result.message)
      if (result.data?.id && !id) {
        setId(result.data.id) // Set the ID if it was a new insert
      }
    } else {
      setMessage(result.message)
    }
    setIsLoading(false)
  }

  return (
    <div className="flex flex-col min-h-[100dvh] items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <Card className="w-full max-w-2xl shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-purple-800">ניהול תוכן סעיף גיבור</CardTitle>
          <CardDescription className="text-gray-600">עדכן את הכותרת והתיאור של סעיף הגיבור בדף הנחיתה.</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-center text-gray-600">טוען תוכן...</p>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="title">כותרת הגיבור</Label>
                <Input
                  id="title"
                  type="text"
                  placeholder="בנה את הנוכחות הדיגיטלית הבאה שלך איתנו"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">תיאור הגיבור</Label>
                <Textarea
                  id="description"
                  placeholder="אנו יוצרים אתרים מודרניים, רספונסיביים ומותאמים אישית..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                  required
                  disabled={isLoading}
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                disabled={isLoading}
              >
                {isLoading ? "שומר..." : "שמור שינויים"}
              </Button>
              {message && (
                <p
                  className={`mt-4 text-center text-sm ${message.includes("שגיאה") ? "text-red-500" : "text-green-600"}`}
                >
                  {message}
                </p>
              )}
            </form>
          )}
          <div className="mt-4 text-center">
            <Button variant="link" asChild className="text-purple-600">
              <Link href="/dashboard">חזור ללוח המחוונים</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

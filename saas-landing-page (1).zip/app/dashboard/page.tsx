import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import Link from "next/link"
// Removed MFASetup import as it's moved to profile page
// import { MFASetup } from "@/components/mfa-setup"

interface Client {
  id: string
  name: string
  email: string
  company: string | null
  created_at: string
}

export default async function DashboardPage() {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: clients, error } = await supabase.from("clients").select("*").order("created_at", { ascending: false })

  const handleSignOut = async () => {
    "use server"
    const cookieStore = cookies()
    const supabase = createClient(cookieStore)
    await supabase.auth.signOut()
    redirect("/login")
  }

  return (
    <div className="flex flex-col min-h-[100dvh] bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <header className="flex items-center justify-between p-4 bg-white/80 backdrop-blur-sm shadow-sm rounded-lg mb-6">
        <h1 className="text-2xl font-bold text-purple-800">לוח מחוונים של לקוחות</h1>
        <form action={handleSignOut}>
          <Button
            type="submit"
            variant="outline"
            className="text-purple-600 border-purple-400 hover:bg-purple-50 bg-transparent"
          >
            התנתק
          </Button>
        </form>
      </header>

      <main className="flex-1 container mx-auto grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl text-purple-700">רשימת לקוחות</CardTitle>
            <CardDescription className="text-gray-600">נהל את הלקוחות והפרויקטים שלך כאן.</CardDescription>
          </CardHeader>
          <CardContent>
            {error && <p className="text-red-500">שגיאה בטעינת לקוחות: {error.message}</p>}
            {!clients || clients.length === 0 ? (
              <p className="text-center text-gray-500">אין לקוחות להצגה. הוסף לקוח חדש!</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">שם</TableHead>
                      <TableHead className="text-right">אימייל</TableHead>
                      <TableHead className="text-right">חברה</TableHead>
                      <TableHead className="text-right">תאריך יצירה</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {clients.map((client: Client) => (
                      <TableRow key={client.id}>
                        <TableCell className="font-medium text-right">{client.name}</TableCell>
                        <TableCell className="text-right">{client.email}</TableCell>
                        <TableCell className="text-right">{client.company || "N/A"}</TableCell>
                        <TableCell className="text-right">
                          {new Date(client.created_at).toLocaleDateString("he-IL")}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
            <div className="mt-6 text-center">
              <Button asChild className="bg-purple-600 hover:bg-purple-700 text-white">
                <Link href="/dashboard/add-client">הוסף לקוח חדש</Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Projects Management Card */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl text-purple-700">ניהול פרויקטים</CardTitle>
            <CardDescription className="text-gray-600">צפה ונהל את הפרויקטים המשויכים ללקוחות שלך.</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <Button asChild className="bg-purple-600 hover:bg-purple-700 text-white">
              <Link href="/dashboard/projects">עבור לניהול פרויקטים</Link>
            </Button>
          </CardContent>
        </Card>

        {/* Profile Management Card */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl text-purple-700">ניהול פרופיל</CardTitle>
            <CardDescription className="text-gray-600">עדכן את פרטי הפרופיל שלך והגדרות אבטחה.</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <Button asChild className="bg-purple-600 hover:bg-purple-700 text-white">
              <Link href="/dashboard/profile">עבור לניהול פרופיל</Link>
            </Button>
          </CardContent>
        </Card>

        {/* Content Management Card */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl text-purple-700">ניהול תוכן אתר</CardTitle>
            <CardDescription className="text-gray-600">עדכן את הטקסטים והתמונות בדף הנחיתה.</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <Button asChild className="bg-purple-600 hover:bg-purple-700 text-white">
              <Link href="/dashboard/content/hero">נהל תוכן גיבור</Link>
            </Button>
            {/* Add more links here for other sections as they become dynamic */}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

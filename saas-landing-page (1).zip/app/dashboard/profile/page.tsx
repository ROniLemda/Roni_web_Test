"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import Link from "next/link"
import { MFASetup } from "@/components/mfa-setup" // Import the MFA setup component

export default function ProfilePage() {
  const [email, setEmail] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmNewPassword, setConfirmNewPassword] = useState("")
  const [message, setMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchUser = async () => {
      const {
        data: { user },
        error,
      } = await supabase.auth.getUser()
      if (error || !user) {
        router.push("/login") // Redirect to login if no user session
      } else {
        setEmail(user.email || "")
      }
    }
    fetchUser()
  }, [supabase, router])

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setMessage("")

    let hasError = false
    const updateData: { email?: string; password?: string } = {}

    // Handle email update
    if (email && email !== (await supabase.auth.getUser()).data.user?.email) {
      updateData.email = email
    }

    // Handle password update
    if (newPassword) {
      if (newPassword !== confirmNewPassword) {
        setMessage("הסיסמאות החדשות אינן תואמות.")
        hasError = true
      } else if (newPassword.length < 6) {
        setMessage("הסיסמה חייבת להיות באורך 6 תווים לפחות.")
        hasError = true
      } else {
        updateData.password = newPassword
      }
    }

    if (hasError) {
      setIsLoading(false)
      return
    }

    if (Object.keys(updateData).length === 0) {
      setMessage("אין שינויים לעדכון.")
      setIsLoading(false)
      return
    }

    const { error } = await supabase.auth.updateUser(updateData)

    if (error) {
      setMessage(`שגיאה בעדכון פרופיל: ${error.message}`)
    } else {
      setMessage("הפרופיל עודכן בהצלחה!")
      setNewPassword("")
      setConfirmNewPassword("")
      // If email was updated, Supabase sends a verification email.
      // The user will need to verify the new email.
      if (updateData.email) {
        setMessage("הפרופיל עודכן בהצלחה! אם שינית את האימייל, אנא בדוק את תיבת הדואר לאימות.")
      }
    }
    setIsLoading(false)
  }

  return (
    <div className="flex flex-col min-h-[100dvh] bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <header className="flex items-center justify-between p-4 bg-white/80 backdrop-blur-sm shadow-sm rounded-lg mb-6">
        <h1 className="text-2xl font-bold text-purple-800">ניהול פרופיל</h1>
        <Button asChild className="bg-purple-600 hover:bg-purple-700 text-white">
          <Link href="/dashboard">חזור ללוח המחוונים</Link>
        </Button>
      </header>

      <main className="flex-1 container mx-auto grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-purple-800">עדכן פרטי פרופיל</CardTitle>
            <CardDescription className="text-gray-600">עדכן את כתובת האימייל והסיסמה שלך.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="email">אימייל</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="newPassword">סיסמה חדשה (השאר ריק אם אינך רוצה לשנות)</Label>
                <Input
                  id="newPassword"
                  type="password"
                  placeholder="********"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  disabled={isLoading}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="confirmNewPassword">אשר סיסמה חדשה</Label>
                <Input
                  id="confirmNewPassword"
                  type="password"
                  placeholder="********"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  disabled={isLoading}
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                disabled={isLoading}
              >
                {isLoading ? "מעדכן..." : "עדכן פרופיל"}
              </Button>
              {message && (
                <p
                  className={`mt-4 text-center text-sm ${message.includes("שגיאה") ? "text-red-500" : "text-green-600"}`}
                >
                  {message}
                </p>
              )}
            </form>
          </CardContent>
        </Card>

        {/* MFA Setup Card - Moved here from dashboard page */}
        <MFASetup />
      </main>
    </div>
  )
}

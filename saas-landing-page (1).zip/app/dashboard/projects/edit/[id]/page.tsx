"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"
import { getProjectById, updateProject } from "@/app/actions/projects" // Import server actions

interface Client {
  id: string
  name: string
  company: string | null
}

interface EditProjectPageProps {
  params: {
    id: string
  }
}

export default function EditProjectPage({ params }: EditProjectPageProps) {
  const projectId = params.id
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [status, setStatus] = useState("Pending")
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [clientId, setClientId] = useState("")
  const [clients, setClients] = useState<Client[]>([])
  const [message, setMessage] = useState("")
  const [isLoading, setIsLoading] = useState(true) // Start as loading to fetch data
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true)
      setMessage("")

      // Fetch clients
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) {
        setMessage("יש להתחבר כדי לטעון לקוחות ופרויקטים.")
        setIsLoading(false)
        return
      }

      const { data: clientsData, error: clientsError } = await supabase
        .from("clients")
        .select("id, name, company")
        .order("name", { ascending: true })
      if (clientsError) {
        setMessage(`שגיאה בטעינת לקוחות: ${clientsError.message}`)
        setIsLoading(false)
        return
      }
      setClients(clientsData || [])

      // Fetch project details
      const project = await getProjectById(projectId)
      if (project) {
        setName(project.name)
        setDescription(project.description || "")
        setStatus(project.status)
        setStartDate(project.start_date || "")
        setEndDate(project.end_date || "")
        setClientId(project.client_id)
      } else {
        setMessage("פרויקט לא נמצא או שאין לך הרשאה לצפות בו.")
      }
      setIsLoading(false)
    }
    fetchData()
  }, [projectId, supabase])

  const handleUpdateProject = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setMessage("")

    if (!clientId) {
      setMessage("אנא בחר לקוח עבור הפרויקט.")
      setIsLoading(false)
      return
    }

    const projectData = {
      name,
      description: description || null,
      status,
      start_date: startDate || null,
      end_date: endDate || null,
      client_id: clientId,
    }

    const result = await updateProject(projectId, projectData)

    if (result.success) {
      setMessage(result.message)
      router.push("/dashboard/projects") // Redirect to projects list after updating
    } else {
      setMessage(result.message)
    }
    setIsLoading(false)
  }

  if (isLoading) {
    return (
      <div className="flex min-h-[100dvh] items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
        <Card className="w-full max-w-md shadow-lg text-center p-6">
          <p className="text-gray-600">טוען פרטי פרויקט...</p>
        </Card>
      </div>
    )
  }

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-purple-800">ערוך פרויקט</CardTitle>
          <CardDescription className="text-gray-600">עדכן את הפרטים של הפרויקט הקיים.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleUpdateProject} className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="client">לקוח</Label>
              <Select value={clientId} onValueChange={setClientId} disabled={isLoading || clients.length === 0}>
                <SelectTrigger id="client">
                  <SelectValue placeholder="בחר לקוח" />
                </SelectTrigger>
                <SelectContent>
                  {clients.length === 0 && (
                    <SelectItem value="" disabled>
                      אין לקוחות זמינים
                    </SelectItem>
                  )}
                  {clients.map((client) => (
                    <SelectItem key={client.id} value={client.id}>
                      {client.name} {client.company ? `(${client.company})` : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="name">שם פרויקט</Label>
              <Input
                id="name"
                type="text"
                placeholder="שם הפרויקט"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                disabled={isLoading}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">תיאור (אופציונלי)</Label>
              <Textarea
                id="description"
                placeholder="תיאור קצר של הפרויקט"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                disabled={isLoading}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="status">סטטוס</Label>
              <Select value={status} onValueChange={setStatus} disabled={isLoading}>
                <SelectTrigger id="status">
                  <SelectValue placeholder="בחר סטטוס" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pending">ממתין</SelectItem>
                  <SelectItem value="In Progress">בתהליך</SelectItem>
                  <SelectItem value="Completed">הושלם</SelectItem>
                  <SelectItem value="On Hold">בהמתנה</SelectItem>
                  <SelectItem value="Cancelled">בוטל</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="startDate">תאריך התחלה (אופציונלי)</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  disabled={isLoading}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="endDate">תאריך סיום (אופציונלי)</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  disabled={isLoading}
                />
              </div>
            </div>
            <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700 text-white" disabled={isLoading}>
              {isLoading ? "מעדכן..." : "עדכן פרויקט"}
            </Button>
            {message && <p className="text-center text-sm text-red-500">{message}</p>}
          </form>
          <div className="mt-4 text-center">
            <Button variant="link" asChild className="text-purple-600">
              <Link href="/dashboard/projects">חזור לרשימת הפרויקטים</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

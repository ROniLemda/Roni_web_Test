import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { DeleteProjectButton } from "@/components/delete-project-button" // Import the new component

interface Project {
  id: string
  client_id: string
  name: string
  description: string | null
  status: string
  start_date: string | null
  end_date: string | null
  created_at: string
  clients: {
    name: string
    company: string | null
  } | null
}

export default async function ProjectsPage() {
  const cookieStore = cookies()
  const supabase = createClient(cookieStore)

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/login")
  }

  const { data: projects, error } = await supabase
    .from("projects")
    .select(
      `
    *,
    clients (
      name,
      company
    )
  `,
    )
    .order("created_at", { ascending: false })

  return (
    <div className="flex flex-col min-h-[100dvh] bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <header className="flex items-center justify-between p-4 bg-white/80 backdrop-blur-sm shadow-sm rounded-lg mb-6">
        <h1 className="text-2xl font-bold text-purple-800">ניהול פרויקטים</h1>
        <Button asChild className="bg-purple-600 hover:bg-purple-700 text-white">
          <Link href="/dashboard">חזור ללוח המחוונים</Link>
        </Button>
      </header>

      <main className="flex-1 container mx-auto">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl text-purple-700">רשימת פרויקטים</CardTitle>
            <CardDescription className="text-gray-600">נהל את הפרויקטים שלך כאן.</CardDescription>
          </CardHeader>
          <CardContent>
            {error && <p className="text-red-500">שגיאה בטעינת פרויקטים: {error.message}</p>}
            {!projects || projects.length === 0 ? (
              <p className="text-center text-gray-500">אין פרויקטים להצגה. הוסף פרויקט חדש!</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-right">שם פרויקט</TableHead>
                      <TableHead className="text-right">לקוח</TableHead>
                      <TableHead className="text-right">סטטוס</TableHead>
                      <TableHead className="text-right">תאריך התחלה</TableHead>
                      <TableHead className="text-right">תאריך סיום</TableHead>
                      <TableHead className="text-right">פעולות</TableHead> {/* New column for actions */}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {projects.map((project: Project) => (
                      <TableRow key={project.id}>
                        <TableCell className="font-medium text-right">{project.name}</TableCell>
                        <TableCell className="text-right">
                          {project.clients
                            ? `${project.clients.name} (${project.clients.company || "ללא חברה"})`
                            : "N/A"}
                        </TableCell>
                        <TableCell className="text-right">{project.status}</TableCell>
                        <TableCell className="text-right">
                          {project.start_date ? new Date(project.start_date).toLocaleDateString("he-IL") : "N/A"}
                        </TableCell>
                        <TableCell className="text-right">
                          {project.end_date ? new Date(project.end_date).toLocaleDateString("he-IL") : "N/A"}
                        </TableCell>
                        <TableCell className="text-right flex justify-end gap-2">
                          <Button asChild variant="outline" size="sm">
                            <Link href={`/dashboard/projects/edit/${project.id}`}>ערוך</Link>
                          </Button>
                          <DeleteProjectButton projectId={project.id} projectName={project.name} />
                        </TableCell>{" "}
                        {/* New cell for actions */}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
            <div className="mt-6 text-center">
              <Button asChild className="bg-purple-600 hover:bg-purple-700 text-white">
                <Link href="/dashboard/projects/add">הוסף פרויקט חדש</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

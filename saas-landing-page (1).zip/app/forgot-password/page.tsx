"use client"

import type React from "react"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import Link from "next/link"

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClient()

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setMessage("")

    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/update-password`,
    })

    if (error) {
      setMessage(`שגיאה: ${error.message}`)
    } else {
      setMessage("קישור לאיפוס סיסמה נשלח לאימייל שלך. אנא בדוק את תיבת הדואר.")
    }
    setIsLoading(false)
  }

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-purple-800">שכחתי סיסמה</CardTitle>
          <CardDescription className="text-gray-600">
            הזן את כתובת האימייל שלך כדי לקבל קישור לאיפוס סיסמה.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleResetPassword} className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="email">אימייל</Label>
              <Input
                id="email"
                type="email"
                placeholder="your@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={isLoading}
              />
            </div>
            <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700 text-white" disabled={isLoading}>
              {isLoading ? "שולח..." : "שלח קישור לאיפוס"}
            </Button>
            {message && <p className="text-center text-sm text-red-500">{message}</p>}
          </form>
          <div className="mt-4 text-center text-sm">
            <Link href="/login" className="text-purple-600 hover:underline">
              חזור להתחברות
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

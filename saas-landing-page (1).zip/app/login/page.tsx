"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import Image from "next/image"
import Link from "next/link"
import { signInWithEmailAndPassword, verify2FACode } from "@/app/actions/auth" // Import the new Server Actions

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [message, setMessage] = useState("")
  const [isSigningUp, setIsSigningUp] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [show2FAInput, setShow2FAInput] = useState(false)
  const [twoFactorCode, setTwoFactorCode] = useState("")
  const [qrCodeImageUrl, setQrCodeImageUrl] = useState<string | null>(null)
  const [sharedSecret, setSharedSecret] = useState<string | null>(null)

  const router = useRouter()
  const supabase = createClient() // Still needed for signup and other client-side Supabase calls

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setMessage("")
    setShow2FAInput(false) // Reset 2FA state

    const result = await signInWithEmailAndPassword(email, password)

    if (!result.success) {
      // If action didn't redirect, it means there was an error
      setMessage(result.message || "שגיאה בהתחברות.")
      if (result.requires2FA) {
        setShow2FAInput(true)
      }
    }
    // No need for else if (data.user) { router.push("/dashboard") } because the Server Action handles redirect
    setIsLoading(false)
  }

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setMessage("")
    const { error } = await supabase.auth.signUp({ email, password })
    if (error) {
      setMessage(error.message)
    } else {
      // Simplified success message for sign-up
      setMessage("נרשמת בהצלחה! כעת תוכל להתחבר.")
      setIsSigningUp(false) // Switch to sign-in view after successful signup
    }
    setIsLoading(false)
  }

  const handle2FACodeVerification = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setMessage("")

    const result = await verify2FACode(email, twoFactorCode)

    if (!result.success) {
      setMessage(result.message || "שגיאת אימות קוד.")
    }
    // No need for else { router.push("/dashboard") } because the Server Action handles redirect
    setIsLoading(false)
  }

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-purple-800">{isSigningUp ? "הירשם" : "התחבר"}</CardTitle>
          <CardDescription className="text-gray-600">
            {isSigningUp ? "צור חשבון חדש." : "התחבר לחשבונך."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!show2FAInput ? (
            <form onSubmit={isSigningUp ? handleSignUp : handleSignIn} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="email">אימייל</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="password">סיסמה</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="********"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                disabled={isLoading}
              >
                {isLoading ? (isSigningUp ? "נרשם..." : "מתחבר...") : isSigningUp ? "הירשם" : "התחבר"}
              </Button>
              {message && <p className="text-center text-sm text-red-500">{message}</p>}
              <div className="text-center text-sm">
                <Link href="/forgot-password" className="text-purple-600 hover:underline">
                  שכחתי סיסמה?
                </Link>
              </div>
            </form>
          ) : (
            <form onSubmit={handle2FACodeVerification} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="twoFactorCode">קוד אימות דו-שלבי</Label>
                <Input
                  id="twoFactorCode"
                  type="text"
                  placeholder="הזן קוד 2FA"
                  value={twoFactorCode}
                  onChange={(e) => setTwoFactorCode(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>
              {qrCodeImageUrl && (
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-2">סרוק את קוד ה-QR עם אפליקציית המאמת שלך:</p>
                  <Image
                    src={qrCodeImageUrl || "/placeholder.svg"}
                    alt="QR Code for 2FA"
                    width={200}
                    height={200}
                    className="mx-auto"
                  />
                  {sharedSecret && (
                    <p className="text-xs text-gray-500 mt-2">
                      או הזן ידנית: <code className="font-mono bg-gray-100 p-1 rounded">{sharedSecret}</code>
                    </p>
                  )}
                </div>
              )}
              <Button
                type="submit"
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                disabled={isLoading}
              >
                {isLoading ? "מאמת..." : "אמת קוד"}
              </Button>
              {message && <p className="text-center text-sm text-red-500">{message}</p>}
            </form>
          )}

          <div className="mt-4 text-center text-sm">
            {!show2FAInput &&
              (isSigningUp ? (
                <>
                  כבר יש לך חשבון?{" "}
                  <Button variant="link" onClick={() => setIsSigningUp(false)} className="p-0 h-auto text-purple-600">
                    התחבר
                  </Button>
                </>
              ) : (
                <>
                  אין לך חשבון?{" "}
                  <Button variant="link" onClick={() => setIsSigningUp(true)} className="p-0 h-auto text-purple-600">
                    הירשם
                  </Button>
                </>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

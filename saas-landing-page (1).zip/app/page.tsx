import Component from "../landing-page"

export default function Page() {
  return <Component />
}

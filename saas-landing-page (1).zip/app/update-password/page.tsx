"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import Link from "next/link"

export default function UpdatePasswordPage() {
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [message, setMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSessionValid, setIsSessionValid] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    // Check if there's an active session (from the reset link)
    const checkSession = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()
      if (session) {
        setIsSessionValid(true)
      } else {
        setMessage("קישור לא חוקי או פג תוקף. אנא בקש קישור חדש.")
      }
    }
    checkSession()
  }, [supabase])

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setMessage("")

    if (password !== confirmPassword) {
      setMessage("הסיסמאות אינן תואמות.")
      setIsLoading(false)
      return
    }

    if (password.length < 6) {
      setMessage("הסיסמה חייבת להיות באורך 6 תווים לפחות.")
      setIsLoading(false)
      return
    }

    const { error } = await supabase.auth.updateUser({ password })

    if (error) {
      setMessage(`שגיאה בעדכון סיסמה: ${error.message}`)
    } else {
      setMessage("הסיסמה עודכנה בהצלחה! אתה יכול להתחבר כעת.")
      router.push("/login")
    }
    setIsLoading(false)
  }

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-purple-800">עדכן סיסמה</CardTitle>
          <CardDescription className="text-gray-600">הזן את הסיסמה החדשה שלך.</CardDescription>
        </CardHeader>
        <CardContent>
          {isSessionValid ? (
            <form onSubmit={handleUpdatePassword} className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="password">סיסמה חדשה</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="********"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="confirmPassword">אשר סיסמה חדשה</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="********"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  disabled={isLoading}
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                disabled={isLoading}
              >
                {isLoading ? "מעדכן..." : "עדכן סיסמה"}
              </Button>
              {message && <p className="text-center text-sm text-red-500">{message}</p>}
            </form>
          ) : (
            <div className="text-center space-y-4">
              <p className="text-red-500">{message}</p>
              <Button asChild className="bg-purple-600 hover:bg-purple-700 text-white">
                <Link href="/forgot-password">בקש קישור חדש</Link>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

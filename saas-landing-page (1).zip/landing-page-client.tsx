"use client" // This directive explicitly marks it as a Client Component

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Layout, Rocket, Users, DollarSign, Check, Instagram, Facebook, Linkedin } from "lucide-react" // Ensure all icons are imported
import { ContactForm } from "@/components/contact-form"
import { useScrollAnimation } from "@/hooks/use-scroll-animation" // Now safe to use here, as this is a Client Component
import { Logo } from "@/components/logo"

interface LandingPageClientProps {
  heroTitle: string
  heroDescription: string
}

export default function LandingPageClient({ heroTitle, heroDescription }: LandingPageClientProps) {
  // Apply the hook to each section - these are now correctly inside a Client Component
  const { ref: heroRef, classes: heroClasses } = useScrollAnimation()
  const { ref: featuresRef, classes: featuresClasses } = useScrollAnimation()
  const { ref: portfolioRef, classes: portfolioClasses } = useScrollAnimation()
  const { ref: servicesRef, classes: servicesClasses } = useScrollAnimation()
  const { ref: testimonialsRef, classes: testimonialsClasses } = useScrollAnimation()
  const { ref: pricingRef, classes: pricingClasses } = useScrollAnimation()
  const { ref: ctaRef, classes: ctaClasses } = useScrollAnimation()

  return (
    <div className="flex flex-col min-h-[100dvh] bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Header */}
      <header className="px-4 lg:px-6 h-14 flex items-center justify-between bg-white/80 backdrop-blur-sm shadow-sm sticky top-0 z-50">
        {/* Logo on the left */}
        <Link href="#" className="flex items-center gap-2 text-xl font-bold text-purple-800">
          <Logo className="h-8 w-auto" /> {/* Adjust height/width as needed for header */}
        </Link>
        {/* Navigation links and button on the right */}
        <div className="flex items-center gap-4 sm:gap-6 ml-auto">
          {" "}
          {/* ml-auto pushes this div to the right */}
          <nav className="flex gap-4 sm:gap-6">
            <Link href="#portfolio" className="text-sm font-medium hover:underline underline-offset-4 text-gray-700">
              תיק עבודות
            </Link>
            <Link href="#services" className="text-sm font-medium hover:underline underline-offset-4 text-gray-700">
              שירותים
            </Link>
            <Link href="#pricing" className="text-sm font-medium hover:underline underline-offset-4 text-gray-700">
              תמחור
            </Link>
            <Link href="#contact" className="text-sm font-medium hover:underline underline-offset-4 text-gray-700">
              צור קשר
            </Link>
          </nav>
          <Button asChild className="bg-purple-600 hover:bg-purple-700 text-white">
            <Link href="/login">כניסת לקוחות</Link>
          </Button>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section
          ref={heroRef}
          className={`w-full py-12 md:py-24 lg:py-32 xl:py-48 bg-gradient-to-r from-purple-600 to-indigo-700 text-white ${heroClasses}`}
        >
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] xl:grid-cols-[1fr_500px] items-center">
              {/* Text content on the right (now first for mobile stacking) */}
              <div className="flex flex-col justify-center space-y-4 text-center lg:text-left">
                <div className="space-y-2">
                  <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">{heroTitle}</h1>
                  <p className="max-w-[600px] text-purple-100 md:text-xl mx-auto lg:ml-auto lg:mr-0">
                    {heroDescription}
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row justify-center lg:justify-start">
                  <Button
                    asChild
                    className="inline-flex h-10 items-center justify-center rounded-md bg-white px-8 text-sm font-medium text-purple-600 shadow transition-colors hover:bg-gray-100 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
                  >
                    <Link href="#contact">קבל הצעת מחיר</Link>
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    className="inline-flex h-10 items-center justify-center rounded-md border border-white/50 bg-transparent px-8 text-sm font-medium text-white shadow-sm transition-colors hover:bg-white/20 hover:text-white focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50"
                  >
                    <Link href="#portfolio">צפה בתיק העבודות</Link>
                  </Button>
                </div>
              </div>
              {/* Logo on the left (now second for mobile stacking) */}
              <div className="flex items-center justify-center lg:justify-center w-full h-full">
                {/* ואז את ה-div הפנימי של המלבן הלבן: */}
                <div className="relative w-[300px] h-[300px] lg:w-[400px] lg:h-[400px] bg-white rounded-xl p-4 overflow-hidden mx-auto">
                  <Logo className="w-full h-full" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Portfolio Section */}
        <section
          id="portfolio"
          ref={portfolioRef}
          className={`w-full py-12 md:py-24 lg:py-32 bg-white ${portfolioClasses}`}
        >
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-purple-800">תיק העבודות שלנו</h2>
                <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  אנו גאים להציג מבחר מהפרויקטים האחרונים שלנו.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-start gap-8 py-12 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
              <Card className="flex flex-col shadow-md hover:shadow-lg transition-shadow duration-300">
                <Image
                  src="https://sjc.microlink.io/YE39x8xWuwcG-hq9XXfL9ZXp6Xo8Pk3qIwEKCz8twjTm8yTqwTqUj9bCibW27-pakg8iFelB9uT060XybPfCrA.jpeg"
                  width="300"
                  height="200"
                  alt="Pookubeh Website Screenshot"
                  className="rounded-t-lg object-cover w-full h-48"
                />
                <CardHeader className="pb-2">
                  <CardTitle className="text-xl font-bold text-purple-700">Pookubeh - אתר הזמנות</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">
                    אתר הזמנות מותאם אישית לקובה ומרקים ביתיים, עם תפריט אינטראקטיבי ומערכת ניהול הזמנות.
                  </p>
                  <Button
                    asChild
                    variant="outline"
                    className="w-full border-purple-400 text-purple-600 hover:bg-purple-50 bg-transparent"
                  >
                    <Link href="https://pookubeh.web.app/" target="_blank" rel="noopener noreferrer">
                      צפה באתר
                    </Link>
                  </Button>
                </CardContent>
              </Card>
              {/* Removed other placeholder cards */}
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section
          id="services"
          ref={servicesRef}
          className={`w-full py-12 md:py-24 lg:py-32 bg-purple-50 ${servicesClasses}`}
        >
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-purple-800">
                  השירותים שאנו מציעים
                </h2>
                <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  אנו מספקים מגוון רחב של שירותי פיתוח ועיצוב אתרים כדי לענות על כל צורך עסקי.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-start gap-8 py-12 sm:grid-cols-2 md:gap-12 lg:grid-cols-3">
              <Card className="flex flex-col items-center text-center p-6 shadow-md bg-white hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <Layout className="h-10 w-10 text-purple-600 mb-4" />
                  <CardTitle className="text-xl font-bold text-purple-700">בניית אתרים מותאמים אישית</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    אנו בונים אתרים ייחודיים מאפס, המותאמים בדיוק לצרכים ולזהות המותג שלך.
                  </p>
                </CardContent>
              </Card>
              <Card className="flex flex-col items-center text-center p-6 shadow-md bg-white hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <DollarSign className="h-10 w-10 text-purple-600 mb-4" />
                  <CardTitle className="text-xl font-bold text-purple-700">פתרונות מסחר אלקטרוני</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">הקמת חנויות אונליין מאובטחות וקלות לניהול, עם שילוב מערכות תשלום.</p>
                </CardContent>
              </Card>
              <Card className="flex flex-col items-center text-center p-6 shadow-md bg-white hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <Rocket className="h-10 w-10 text-purple-600 mb-4" />
                  <CardTitle className="text-xl font-bold text-purple-700">אופטימיזציה וקידום</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">שיפור ביצועי האתר, מהירות טעינה ואופטימיזציה למנועי חיפוש (SEO).</p>
                </CardContent>
              </Card>
              <Card className="flex flex-col items-center text-center p-6 shadow-md bg-white hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <Users className="h-10 w-10 text-purple-600 mb-4" />
                  <CardTitle className="text-xl font-bold text-purple-700">תמיכה ותחזוקה</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">שירותי תמיכה שוטפים, עדכונים ותחזוקה כדי שהאתר שלך יפעל בצורה חלקה.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section
          id="pricing"
          ref={pricingRef}
          className={`w-full py-12 md:py-24 lg:py-32 bg-purple-50 ${pricingClasses}`}
        >
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl text-purple-800">חבילות בניית אתרים</h2>
                <p className="max-w-[900px] text-gray-600 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  מצא את החבילה המושלמת עבור הפרויקט הדיגיטלי הבא שלך.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-start gap-8 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
              {/* Basic Website Plan */}
              <Card className="flex flex-col p-6 shadow-lg border-2 border-purple-200 hover:border-purple-400 transition-colors duration-300 bg-white">
                <CardHeader className="pb-4 text-center">
                  <CardTitle className="text-2xl font-bold text-purple-700">אתר תדמית בסיסי</CardTitle>
                  <p className="text-4xl font-extrabold text-purple-800 mt-2">החל מ-₪85</p>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  <ul className="space-y-2 text-gray-700 mb-6 text-right">
                    <li className="flex items-center justify-end gap-2">
                      עד 5 עמודים
                      <Check className="h-5 w-5 text-green-500" />
                    </li>
                    <li className="flex items-center justify-end gap-2">
                      עיצוב רספונסיבי
                      <Check className="h-5 w-5 text-green-500" />
                    </li>
                    <li className="flex items-center justify-end gap-2">
                      טופס יצירת קשר
                      <Check className="h-5 w-5 text-green-500" />
                    </li>
                  </ul>
                  <Button asChild className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                    <Link href="#contact">קבל הצעת מחיר</Link>
                  </Button>
                </CardContent>
              </Card>

              {/* E-commerce Plan */}
              <Card className="flex flex-col p-6 shadow-lg border-2 border-purple-600 bg-purple-600 text-white">
                <CardHeader className="pb-4 text-center">
                  <CardTitle className="text-2xl font-bold text-white">חנות אונליין מלאה</CardTitle>
                  <p className="text-4xl font-extrabold text-white mt-2">החל מ-₪250</p>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  <ul className="space-y-2 text-purple-100 mb-6 text-right">
                    <li className="flex items-center justify-end gap-2">
                      ניהול מוצרים ומלאי
                      <Check className="h-5 w-5 text-green-300" />
                    </li>
                    <li className="flex items-center justify-end gap-2">
                      שילוב מערכות תשלום
                      <Check className="h-5 w-5 text-green-300" />
                    </li>
                    <li className="flex items-center justify-end gap-2">
                      עגלת קניות מאובטחת
                      <Check className="h-5 w-5 text-green-300" />
                    </li>
                    <li className="flex items-center justify-end gap-2">
                      דוחות מכירה
                      <Check className="h-5 w-5 text-green-300" />
                    </li>
                  </ul>
                  <Button asChild className="w-full bg-white hover:bg-gray-100 text-purple-600">
                    <Link href="#contact">קבל הצעת מחיר</Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Custom Solution Plan */}
              <Card className="flex flex-col p-6 shadow-lg border-2 border-purple-200 hover:border-purple-400 transition-colors duration-300 bg-white">
                <CardHeader className="pb-4 text-center">
                  <CardTitle className="text-2xl font-bold text-purple-700">פתרון מותאם אישית</CardTitle>
                  <p className="text-4xl font-extrabold text-purple-800 mt-2">צור קשר</p>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  <ul className="space-y-2 text-gray-700 mb-6 text-right">
                    <li className="flex items-center justify-end gap-2">
                      פיתוח מערכות מורכבות
                      <Check className="h-5 w-5 text-green-500" />
                    </li>
                    <li className="flex items-center justify-end gap-2">
                      אינטגרציות צד שלישי
                      <Check className="h-5 w-5 text-green-500" />
                    </li>
                    <li className="flex items-center justify-end gap-2">
                      ייעוץ אסטרטגי
                      <Check className className="h-5 w-5 text-green-500" />
                    </li>
                    <li className="flex items-center justify-end gap-2">
                      תמיכה מקיפה
                      <Check className="h-5 w-5 text-green-500" />
                    </li>
                  </ul>
                  <Button asChild className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                    <Link href="#contact">צור קשר</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Final Call to Action Section */}
        <section
          id="contact"
          ref={ctaRef}
          className={`w-full py-12 md:py-24 lg:py-32 bg-gradient-to-br from-purple-600 to-indigo-700 text-white text-center ${ctaClasses}`}
        >
          <div className="container px-4 md:px-6">
            <div className="space-y-8">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">מוכן לבנות את האתר הבא שלך?</h2>
                <p className="mx-auto max-w-[700px] text-purple-100 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  צור קשר עוד היום לקבלת ייעוץ חינם והצעת מחיר מותאמת אישית.
                </p>
              </div>
              <ContactForm />
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t bg-white/80 backdrop-blur-sm">
        <p className="text-xs text-gray-600">&copy; {new Date().getFullYear()} WebFlow Solutions. כל הזכויות שמורות.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link href="#" className="text-xs hover:underline underline-offset-4 text-gray-700">
            תנאי שירות
          </Link>
          <Link href="#" className="text-xs hover:underline underline-offset-4 text-gray-700">
            מדיניות פרטיות
          </Link>
          <Link href="#contact" className="text-xs hover:underline underline-offset-4 text-gray-700">
            צור קשר
          </Link>
        </nav>
        <div className="flex gap-4 mt-4 sm:mt-0">
          <Link href="#" aria-label="פייסבוק">
            <Facebook className="h-5 w-5 text-gray-600 hover:text-purple-600 transition-colors" />
          </Link>
          <Link href="#" aria-label="אינסטגרם">
            <Instagram className="h-5 w-5 text-gray-600 hover:text-purple-600 transition-colors" />
          </Link>
          <Link href="#" aria-label="לינקדאין">
            <Linkedin className="h-5 w-5 text-gray-600 hover:text-purple-600 transition-colors" />
          </Link>
        </div>
      </footer>
    </div>
  )
}
